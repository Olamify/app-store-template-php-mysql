<?php
session_start();

// initializing variables
$username = "";
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'olamify');

// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if ($password_1 != $password_2) {
	array_push($errors, "Passwords do not match");
  }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['username'] === $username) {
      array_push($errors, "Username already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }
  }

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	$password = md5($password_1);//encrypt the password before saving in the database

  	$query = "INSERT INTO users (username, email, password) 
  			  VALUES('$username', '$email', '$password')";
  	mysqli_query($db, $query);
    $uname = ucfirst($username);
  	$_SESSION['username'] = $uname;
  	$_SESSION['email'] = $email;
  	$_SESSION['success'] = "Welcome $uname This is the OLAMIFY APP STORE";
  	header("location: /index.php");
  }
}
// ... 

// LOGIN USER
if (isset($_POST['login_user'])) {
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password = mysqli_real_escape_string($db, $_POST['password']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  if (empty($username)) {
  	array_push($errors, "Username is required");
  }
  if (empty($password)) {
  	array_push($errors, "Password is required");
  }
  if (empty($email)) {
  	array_push($errors, "Email is required");
  }

  if (count($errors) == 0) {
  	$password = md5($password);
  	$query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
  	$results = mysqli_query($db, $query);
  	if (mysqli_num_rows($results) == 1) {
      $uname = ucfirst($username);
  	  $_SESSION['username'] = $uname;
  	  $_SESSION['email'] = $email;
  	  $_SESSION['success'] = "Welcome $uname we've missed you";
  	  header("location: /index.php");
  	}else {
  		array_push($errors, "Username and Password do not match");
  	}
  }
}

// Change uname
if (isset($_POST['update_uname'])) {


$servername = "localhost";
$uername = "root";
$pssword = "";
$dname = "olamify";
$uname1 = mysqli_real_escape_string($db, $_POST['uname']);
$email1 = mysqli_real_escape_string($db, $_POST['email']);

if (empty($uname1)) {
  array_push($errors, "Username is required");
}
// Create connection
$conn = new mysqli($servername, $uername, $pssword, $dname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed");
}

$sql = "UPDATE users SET username='$uname1' WHERE email='$email1'";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Please Login to take changes.. Logging out.. Remember to login with the name => ".$uname1."<=');location.assign('index.php?logout=1')</script>";
} else {
    echo "Error updating record";
}
$conn->close();
}
?>