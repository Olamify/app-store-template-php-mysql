    <link rel="stylesheet" type="text/css" href="/assets/css/w3.css">
    <link rel="stylesheet" type="text/css" href="/assets/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="/assets/css/olamify.css">
<!--    <script src="/assets/js/bootstrap.min.js"></script>  -->
    <script src="/assets/js/angular.min.js"></script>
    <script src="/assets/js/jquery.min.js"></script>
    <style>input{outline: none;}  .sticky {position:fixed;}</style>
    <link rel="shortcut icon" href="/assets/images/favicon.ico" type="image/x-icon">

    <script src="/maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
      <script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script>
<style>
  body,h1,h2,h3,h4,h5,h6 {font-family: "Segoe UI", sans-serif;user-zoom:none;}
  .w3-bar,h1,button {font-family: "Segoe UI", sans-serif}
  .lg {font-size:50px}
  .ad:hover{text-decoration:none;}
  .rnd{border-radius:100px;height:200px;width:200px;font-size:100px;}
  .w3-highway-brown
  {color:#fff;background-color:#633517}
  
  .w3-highway-red
  {color:#fff;background-color:#a6001a}
  
  .w3-highway-orange
  {color:#fff;background-color:#e06000}
  
  .w3-highway-schoolbus
  {color:#fff;background-color:#ee9600}
  
  .w3-highway-yellow
  {color:#fff;background-color:#ffab00}
  
  .w3-highway-green
  {color:#fff;background-color:#004d33}
  
  .w3-highway-blue
  {color:#fff;background-color:#00477e}
</style>
