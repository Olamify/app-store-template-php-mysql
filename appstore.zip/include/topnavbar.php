<!-- Navbar -->
<div class="w3-top bg1 noselect">
  <div class="w3-bar w3-card w3-hide-small w3-hide-medium w3-left-align w3-large">
    <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large bg1" href="javascript:void(0);" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="/" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white"><i class="fa fa-home"></i> Home</a>
    <a href="/apps/" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white">Apps</a>
    <a href="/games/" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white"><i class="fa fa-gamepad"></i> Games</a>
    <a href="/profile/" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white"><i class="fa fa-user"></i> My Profile</a>
    <a href="/coding-videos/" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white"><i class="fa fa-code"></i> Coding</a>
    <a href="index.php?logout=1" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white w3-right text-danger"><i class="fa fa-key"></i>Logout</a>
  </div>

  <!-- Navbar on small screens -->
  <div class="w3-bar sticky w3-round-large w3-bottom w3-hide-large w3-large bg1">
    <a href="/" class="w3-bar-item w3-button w3-button1 w3-padding-large" style="width:16.66666666666667%"><i class="fa fa-home"></i>Home</a>
    <a href="/games/" class="w3-bar-item w3-button w3-button1 w3-padding-large" style="width:16.66666666666667%"><i class="fa fa-gamepad"></i>Games</a>
    <a href="/profile/" class="w3-bar-item w3-button w3-button1 w3-padding-large" style="width:16.66666666666667%"><i class="fa fa-user"></i>Profile</a>
    <a href="/apps/" class="w3-bar-item w3-button w3-button1 w3-padding-large" style="width:16.66666666666667%"><i class="fa fa-gamepad"></i>Apps</a>
    <a href="/coding-videos/" class="w3-bar-item w3-button w3-button1 w3-padding-large" style="width:16.66666666666667%"><i class="fa fa-code"></i>Coding</a>
    <a href="index.php?logout=1" class="w3-bar-item w3-button w3-button1 w3-padding-large text-danger" style="width:16.66666666666667%"><i class="fa fa-key"></i>Logout</a>
    </div>
  </div>
</div>