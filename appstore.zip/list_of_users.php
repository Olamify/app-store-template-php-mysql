<?php
include "include/head.tags.php";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "olamify";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, username, reg_date FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table class='w3-table w3-striped w3-padding-32 w3-bordered w3-table-all w3-centered'><tr><th>ID</th><th>UserName</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["id"]."</td><td>".$row["username"]."</td><td>".$row["reg_date"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>