<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first REDIRECTING...";
  	header('location: ../login/');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: ../login/");
  }
?>
<!DOCTYPE html>
<html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    	<title>Olamify App Store - Get Apps and Games</title>
        <?php include("../include/head.tags.php");?>
        <style>
            body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif;user-zoom:none;}
            .w3-bar,h1,button {font-family: "Montserrat", sans-serif}
            .lg {font-size:50px}
            .ad:hover{text-decoration:none;}
            .rnd{border-radius:100px;height:200px;width:200px;font-size:100px;}
        </style>
    </head>

<body>

<?php include("../include/topnavbar.php");?>

<!-- Header -->
<header class="w3-container bg1 w3-center" style="padding:128px 16px">
  <h1 class="w3-margin w3-jumbo">Olamify App Store</h1>
  <p class="w3-xlarge">2022 - <?php echo date('Y');?></p>
</header>

<!-- First Grid -->
<div class="w3-row-padding w3-padding-64 w3-container">
  <div class="w3-content">
    <div class="w3-twothird">
    <?php if (isset($_SESSION['success'])) : ?>
                      <div class="error success" >
                      	<h3>
                          <?php 
                          	echo $_SESSION['success']; 
                          	unset($_SESSION['success']);
                          ?>
                      	</h3>
                      </div>
                  	<?php endif ?>
                    
      <h1>Hello, <?php echo $_SESSION["username"]; ?></h1>
      <h5 class="w3-padding-32">Here are some apps you may like:</h5>
      <div class="w3-container w3-padding-32 w3-grey w3-round"><a href="_Olamify_Word_Search_v1_17370463.apk" download="OlamifyWordSearch" class="text-primary w3-button1 w3-round-large w3-button"><img src="/assets/images/wsearch1.png" width="50" height="50" class="noselect"><br>Olamify Word Search</a><a href="_Olamify_NG_Official_App_17397372.apk" download="OlamifyNgApp" class="text-primary w3-button1 w3-round-large w3-button"><img class="w3-round-large" src="/assets/images/favicon.ico" width="50" height="50" class="noselect"><br>Olamify NG App</a><a href="_Olamify_Spin_the_Bottle_App_V1_17370627.apk" download="OlamifySpinTheBottle" class="text-primary w3-button1 w3-round-large w3-button"><img class="w3-round-large w3-grayscale-max" src="/assets/images/favicon.ico" width="50" height="50" class="noselect"><br>Olamify Spin The Bottle</a></div>

      <p class="w3-text-grey w3-padding">Whatsapp Us by clicking this: <a href="http://wa.me/2349157456510/" class="w3-button1 bg1 w3-button noselect">Whatsapp Us</a></p>
    </div>

    <div class="w3-twothird w3-display-center w3-center">
      <i class="fa w3-black rnd fa-paper-plane w3-display-center w3-padding-64 w3-text-blue"></i><span style="display: inline;" class="w3-round-large w3-green w3-padding-large"><button class="w3-text-white w3-button w3-black ad" href="javascript:void(0);" onclick="openTelegramchannel();">Join&nbsp;our&nbsp;Telegram&nbsp;channel&nbsp;at&nbsp;https://t.me/olamify101</button></span>
    </div>
  </div>
</div>

<!-- Second Grid -->
<div class="w3-row-padding w3-light-grey w3-padding-64 w3-container">
  <div class="w3-content">
    <div class="w3-third w3-center">
      <i class="fa fa-edit w3-black rnd w3-padding-64 w3-text-green w3-margin-right"></i>
    </div>

    <div class="w3-twothird">
      <h1>Feel Free To Telegram Us</h1>
      <div class="alert alert-info alert-dismissible">
    <a href="#" class="close lg" data-dismiss="alert" aria-label="close">&times;</a>
    <a class="w3-padding-32 w3-round-large text-primary" href="http://t.me/olamify"><h2>@olamify</h2></a>
  </div>

      <p class="w3-text-grey">Please note that calls will not be answered</p>
    </div>
  </div>
</div>

<div class="w3-container w3-black w3-center w3-opacity w3-padding-64">
    <h1 class="w3-margin w3-xlarge">Olamify App Store 2022&nbsp;|&nbsp;<?php echo date("Y");?></h1>
</div>

<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-opacity">  
  <div class="w3-xlarge w3-padding-32">
    <a href="tel:+2349157456510"><i class="fa fa-phone w3-hover-opacity"></i></a>
    <a href="http://t.me/olamify"><i class="fa fa-paper-plane w3-hover-opacity"></i></a>
    <a href="http://wa.me/2349157456510"><i class="fa w3-hover-opacity">&#xf086;</i></a>
    <a href="http://t.me/olamify101"><i class="fa fa-question w3-hover-opacity"></i></a>
 </div>
 <p>Powered by <a href="http://dash.infinityfree.com/" target="_blank">InfinityFree</a></p>
</footer>
<script>
function openTelegramchannel() {
OTCwindow =  window.open("http://t.me/olamify101","_blank","toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=500, height=650");
OTCwindow.moveTo(500, 100);
}
</script>
<script>
  $('.dropdown-toggle').dropdown();
// Used to toggle the menu on small screens when clicking on the menu button
function myFunction() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}
</script>

</body>
</html>
