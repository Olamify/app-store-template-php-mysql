<?php include "../include/server.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Olamify App Store - Get Apps and Games&nbsp;|&nbsp;Login</title>
    <?php include "../include/head.tags.php";?>
    <style>html{text-align:center;}</style>
</head>
<body>
  <div class="header">
  	<h2>Olamify App Store - Get Apps and Games&nbsp;|&nbsp;Register</h2>
  </div>
	
  <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  	<?php include('../include/errors.php'); ?>
	<div class="input-group">
  	  <label>Username</label>
  	  <input type="text" class="w3 w3-padding-16" name="username" value="<?php echo $username; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" class="w3 w3-padding-16" name="email" value="<?php echo $email; ?>">
  	</div>
  	<div class="input-group w3 w3-padding-16">
  	  <label>Password</label>
  	  <input type="password" class="w3 w3-padding-16" name="password_1">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" class="w3 w3-padding-16" name="password_2">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Register</button>
  	</div>
  	<p>
  		Already a member? <a href="/login" class="text-primary"><b>Sign in</b></a>
  	</p>
  </form>
</body>
</html>