<!DOCTYPE html>
<html lang="en">
<head>
  <?php include "../../../include/head.tags.php";?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>How to Install a Local Server</title>
</head>
<body>
<div style="text-align:center"> 
  <video autoplay id="video1" width="420">
    <source src="../../videos/How_to_install_a_local_server.mp4" type="video/mp4">
    Your browser does not support MP4 videos, you can download it via this link: http://<?php echo $_SERVER['SERVER_NAME'];?>/coding-videos/videos/How_to_install_a_local_server.mp4
  </video>
  <div class="w3-green w3-round-large">    <br>
  <button onclick="playPause()" id="play" class="w3-circle w3-black w3-button"><i id="play" class="fa fa-pause"></i></button> 
  <button onclick="makeBig()" class="w3-circle w3-black w3-button"><i class="fa fa-expand"></i></button>
  <button onclick="makeSmall()" class="w3-circle w3-black w3-button"><i class="fa fa-compress"></i></button>
  <button onclick="makeNormal()" class="w3-circle w3-black w3-button"><i class="fa fa-arrows-alt"></i></button>
      <br><br></div><br>
  <button onclick="location.assign('../')" class="w3-text-white w3-block w3-black w3-padding-8 w3-button">More Videos</h3>
</div> 
<script src="../../vid.js"></script>
<script> 
$("#play").click(function(){
  if (myVideo.paused) {
  $("i#play").removeClass("fa-pause");
  $("i#play").addClass("fa-play");
  } else {
  $("i#play").removeClass("fa-play");
  $("i#play").addClass("fa-pause");
  }
});
var myVideo = document.getElementById("video1"); 
myVideo.muted = true;

</script> </div>
</body>
</html>