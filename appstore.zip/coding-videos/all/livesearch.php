<?php
$xmlDoc=new DOMDocument();
$xmlDoc->load("videos.xml");

$x=$xmlDoc->getElementsByTagName('link');

//get the q parameter from URL
$q=$_GET["q"];

//lookup all links from the xml file if length of q>0
if (strlen($q)>0) {
  $hint="";
  for($i=0; $i<($x->length); $i++) {
    $y=$x->item($i)->getElementsByTagName('title');
    $z=$x->item($i)->getElementsByTagName('url');
    if ($y->item(0)->nodeType==1) {
      //find a link matching the search text
      if (stristr($y->item(0)->childNodes->item(0)->nodeValue,$q)) {
        if ($hint=="") {
          $hint="<a style='width: 100%;' class='w3-padding w3-white w3-button' href='" .
          $z->item(0)->childNodes->item(0)->nodeValue .
          "' target='_self'>" .
          $y->item(0)->childNodes->item(0)->nodeValue . "</a>";
        } else {
          $hint=$hint . "<br /><a style='width: 100%;' class='w3-padding w3-white w3-button' href='" .
          $z->item(0)->childNodes->item(0)->nodeValue .
          "' target='_self'>" .
          $y->item(0)->childNodes->item(0)->nodeValue . "</a>";
        }
      }
    }
  }
}

// Set output to "no suggestion" if no hint was found
// or to the correct values
if ($hint=="") {
  $response="<img src='/assets/images/programming.gif' class='w3-round-large w3-large'><br>We couldn't find that video";
} else {
  $response=$hint;
}

//output the response
echo $response;
?>