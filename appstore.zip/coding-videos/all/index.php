<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="/assets/css/w3.css">
        <link rel="stylesheet" type="text/css" href="/assets/fontawesome/css/font-awesome.min.css">
        <style>
            body {
              font-family: Arial;
            }
        
            * {
              box-sizing: border-box;
            }
            #livesearch {
              width: 100%;
            }
            form.search input[type=text] {
              outline: none;
              padding: 10px;
              font-size: 17px;
              border: 1px solid grey;
              float: left;
              width: 100%;
              background: #f1f1f1;
            }

            form.search button {
              float: left;
              width: 20%;
              padding: 10px;
              background: #2196F3;
              color: white;
              font-size: 17px;
              border: 1px solid grey;
              border-left: none;
              cursor: pointer;
            }

            form.search button:hover {
              background: #0b7dda;
            }

            form.search::after {
              content: "";
              clear: both;
              display: table;
            }
        </style>
    </head>
<body>
<form class="search" action="<?php echo htmlspecialchars("index.php")?>" method="post">
  <input type="text" class="w3-blue w3-center w3-round-large" placeholder="Search Olamify Videos.." name="search" onkeyup="showResult(this.value)">
  <div class="w3-padding w3-white w3-third w3-center" id="livesearch"></div>
</form>
<script>
    function showResult(str) {
      if (str.length==0) {
        document.getElementById("livesearch").innerHTML="";
        document.getElementById("livesearch").style.border="0px";
        return;
      }
      if (window.XMLHttpRequest) {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
      } else {  // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
      }
      xmlhttp.onreadystatechange=function() {
        if (this.readyState==4 && this.status==200) {
          document.getElementById("livesearch").innerHTML=this.responseText;
          document.getElementById("livesearch").style.border="1px solid #A5ACB2";
        }
      }
      xmlhttp.open("GET","livesearch.php?q="+str,true);
      xmlhttp.send();
    }
</script>
</head>
</body>
</html>
